create database Walmart_DB;
use Walmart_DB;

select * from walmart;

--
select count(*) from walmart;

select payment_method, 
		count(*)
from walmart
group by payment_method;  

select count(distinct branch)
from walmart;
 
Select min(quantity) from walmart;

-- Business Problems.

-- Q1. Find different payment method and number of transactions, number of quantity sold
Select 
	payment_method,
    count(*) as no_payments,
    sum(quantity) as no_qty_sold
from walmart
group by payment_method;

-- Q2. Identify the highest-rated category in each branch, displaying the branch, category AVG RATING
SELECT *
FROM (
    SELECT
        branch,
        category,
        AVG(rating) AS avg_rating,
        RANK() OVER (PARTITION BY branch ORDER BY AVG(rating) DESC) AS category_rank
    FROM walmart
    GROUP BY branch, category
) AS ranked_categories  -- Added the alias "ranked_categories"
WHERE category_rank = 1;

-- Q3. Identify the busiest day for each branch based on the number of transactions

SELECT *
FROM (
    SELECT
        branch,
        DATE_FORMAT(STR_TO_DATE(date, '%d/%m/%Y'), '%W') AS day_name,
        COUNT(*) AS no_transactions,
        RANK() OVER (PARTITION BY branch ORDER BY COUNT(*) DESC) AS rank_order  -- Corrected RANK() syntax
    FROM walmart
    GROUP BY branch, day_name
) AS ranked_transactions  -- Added alias for the subquery
WHERE rank_order = 1;  -- Corrected column name in the WHERE clause

-- Q4. Calculate the total quantity of items sold per payment method. List payment_method and total_quantity.

SELECT payment_method,
	SUM(quantity) as no_quantity_sold
from walmart
GROUP BY payment_method;

-- Q5. Determine the average, minimum and maximum rating of category for each city. List the city, average_rating, min_rating and max_rating.

SELECT 
	city,
    category,
    MIN(rating) as min_rating,
    MAX(rating) as max_rating,
    AVG(rating) as avg_rating
FROM Walmart
GROUP BY city, category;

-- Q6. Calculate the total profit for each category by considering total_profit as (unit_price * quantity * profit_margin). List category and total_profit, ordered from highest to lowest profiit.

SELECT
	category, 
    sum(total) as total_revenue,
    sum(total * profit_margin) as profit
FROM walmart
GROUP BY category;

-- Q7. Determine the most common payment method for each branch. Display Branch and the preferred_payment_method

WITH CTE
AS
(SELECT branch, payment_method,
		count(*) AS total_transactions,
        RANK() OVER(PARTITION BY branch ORDER BY COUNT(*) DESC) AS payment_method_rank
FROM walmart
GROUP BY branch, payment_method
)
SELECT * FROM CTE
WHERE payment_method_rank = 1;

-- Q8. Categorize sales into 3 group MORNING, AFTERNOON, EVENING find out the number of transaction each of the shift and number of invoices

WITH TimeOfDay AS (
    SELECT
        *,
        CASE
            WHEN HOUR(time) < 12 THEN 'MORNING'
            WHEN HOUR(time) BETWEEN 12 AND 17 THEN 'AFTERNOON'
            ELSE 'EVENING'
        END AS day_time
    FROM WALMART
)
SELECT
    day_time, branch,
    COUNT(*) AS transaction_count
FROM TimeOfDay
GROUP BY day_time, branch
ORDER BY day_time, transaction_count desc;

-- Q9. Identify 5 branch with highest decrease ratio in revenue compare to last year (current year 2023 and last year 2022).

SELECT *,
       EXTRACT(YEAR FROM STR_TO_DATE(date, '%d/%m/%Y')) AS formatted_year
FROM WALMART; 

WITH revenue_2022 AS (
    SELECT
        branch,
        SUM(total) AS revenue
    FROM WALMART
    WHERE EXTRACT(YEAR FROM STR_TO_DATE(date, '%d/%m/%Y')) = 2022
    GROUP BY branch
),
revenue_2023 AS (
    SELECT
        branch,
        SUM(total) AS revenue
    FROM WALMART
    WHERE EXTRACT(YEAR FROM STR_TO_DATE(date, '%d/%m/%Y')) = 2023
    GROUP BY branch
)
SELECT
    last_year_sale.branch,
    last_year_sale.revenue AS last_year_sale_revenue,
    current_year_sale.revenue AS current_year_sale_revenue,
    CAST(ROUND((last_year_sale.revenue - current_year_sale.revenue) / last_year_sale.revenue * 100, 2) AS DECIMAL(10, 2)) AS revenue_decrease_ratio
FROM revenue_2022 AS last_year_sale
INNER JOIN revenue_2023 AS current_year_sale ON last_year_sale.branch = current_year_sale.branch
WHERE last_year_sale.revenue > current_year_sale.revenue
ORDER BY revenue_decrease_ratio DESC
LIMIT 5;

